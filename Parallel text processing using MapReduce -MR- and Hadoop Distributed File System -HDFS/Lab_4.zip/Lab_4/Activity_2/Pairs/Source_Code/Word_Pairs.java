import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.Reducer;

public class Word_Pairs {
	
	
	private static class MyMapper extends Mapper<LongWritable, Text, WPair, IntWritable> {

		private final WPair pair = new WPair();
		private IntWritable ONE = new IntWritable(1);
		@Override
		public void map(LongWritable key, Text line, Context context) throws IOException,
				InterruptedException {
			String text = line.toString();
			text = text.replaceAll("[^a-zA-Z0-9 ]", "");
			String[] terms = text.split(" ");
			for (int i = 0; i < terms.length; i++){
				terms[i] = terms[i].toLowerCase();
			}
			
			if(terms.length>1){
			for (int i = 0; i < (terms.length-1); i++) {
				if(terms[i].length() != 0){
					for (int j = i + 1; j < terms.length; j++) {
						if (terms[j].length() != 0){
							if(terms[i].compareTo(terms[j]) < 0){
								pair.set(terms[i], terms[j]);
							}
							else{
								pair.set(terms[j], terms[i]);
							}
						}
						context.write(pair, ONE);
					}
				}
				}
			}
		}
	}
	
	public static class MyReducer extends Reducer<WPair,IntWritable,WPair,IntWritable> {
	    private IntWritable Final_count = new IntWritable();
	    @Override
	    protected void reduce(WPair key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
	        int count = 0;
	        for (IntWritable value : values) {
	             count += value.get();
	        }
	        Final_count.set(count);
	        context.write(key,Final_count);
	    }
	}
	

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub
		
		Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Tweet_Pairs");
	    job.setJarByClass(Word_Pairs.class);
	    job.setMapperClass(MyMapper.class);
//	    job.setCombinerClass(MyReducer.class);
	    job.setReducerClass(MyReducer.class);
	    job.setOutputKeyClass(WPair.class);
	    job.setOutputValueClass(IntWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);

	}

}
