import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class WPair implements Writable,WritableComparable <WPair> {
	
	private Text current;
    private Text partner;

	public WPair() {
		
		current = new Text();
		partner = new Text();	
		// TODO Auto-generated constructor stub
	}

	public int compareTo(WPair pair) {
		int c = current.compareTo(pair.current);
		if( c == 0 ){
			c = partner.compareTo(pair.partner);
		}
		// TODO Auto-generated method stub
		return c;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		current.readFields(arg0);
		partner.readFields(arg0);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		current.write(arg0);
		partner.write(arg0);
		// TODO Auto-generated method stub
		
	}
	
	public void set(String current, String partner){
        this.current.set(current);
        this.partner.set(partner);
    }
	
	public Text get_current(){
        return current;
    }
	
	public Text get_partner(){
        return partner;
    }
	
	@Override
    public String toString() {
        return current.toString() +", "+ partner.toString();
    }


}
