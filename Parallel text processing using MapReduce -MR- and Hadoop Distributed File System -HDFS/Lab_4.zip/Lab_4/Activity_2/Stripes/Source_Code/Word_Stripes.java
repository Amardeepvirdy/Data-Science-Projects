import java.io.IOException;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Word_Stripes {

		private static class MyMapper extends
				Mapper<LongWritable, Text, Text, MyMap> {

			private MyMap map = new MyMap();
			private Text word = new Text();
			private IntWritable ONE = new IntWritable(1);

			@Override
			public void map(LongWritable key, Text line, Context context) throws IOException,
					InterruptedException {
				String text = line.toString();

				String[] terms = text.split(" ");
				
				if(terms.length>1){
					for (int i = 0; i < terms.length-1; i++) {
					// skip empty tokens
						if (terms[i].length() != 0){
							map.clear();
							for (int j = i+1; j < terms.length; j++) {
								// skip empty tokens
								if (terms[j].length() != 0){
									if (map.containsKey(terms[j])) {
										IntWritable number = (IntWritable) map.get(terms[j]);
										int new_number = number.get() + 1;
										number.set(new_number);
									} else {
										Text partner = new Text(terms[j]);
										map.put(partner, ONE);
									}
								}
							}
						word.set(terms[i]);
						context.write(word, map);
						}
					}
				}
			}
		}
		
		public static class MyReducer extends Reducer<Text, MyMap, Text, MyMap> {
		    private MyMap Final_Map = new MyMap();

		    //@Override
		    protected void reduce(Text key, Iterable<MyMap> values, Context context) throws IOException, InterruptedException {
		        Final_Map.clear();
		        for (MyMap value : values) {
		        	Set<Writable> keys = value.keySet();
		        	for (Writable key1 : keys) {
			            IntWritable count1 = (IntWritable) value.get(key1);
			            if (Final_Map.containsKey(key1)) {
			                IntWritable number = (IntWritable) Final_Map.get(key1);
			                int new_number = number.get() + count1.get();
							number.set(new_number);
			            } else {
			                Final_Map.put(key1, count1);
			            }
			        }
		        }
		        context.write(key, Final_Map);
		    }
		}

	public Word_Stripes() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub
		
		Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Tweet_Pairs");
	    job.setJarByClass(Word_Stripes.class);
	    job.setMapperClass(MyMapper.class);
//	    job.setCombinerClass(MyReducer.class);
	    job.setReducerClass(MyReducer.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(MyMap.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);

	}

}
