import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Latin_count {
	public static HashMap<String, ArrayList<String>> hash;
	
	public static class MyMapper extends Mapper<LongWritable, Text, Text, Text> {
	    @Override
	    protected void map(LongWritable key, Text line, Context context) throws IOException, InterruptedException {
	    	String text = line.toString();
			String[] parts = text.split(">");
			if(parts.length<2){
				return;
			}
			String val = parts[0] + ">";
			parts[1] = parts[1].replaceAll("[^a-zA-Z ]", "");
			String[] terms = parts[1].split(" ");
			String[] final_terms = new String[terms.length];
			for (int i = 0; i < terms.length; i++){
				String term = terms[i].toLowerCase();
				term = term.replace("j", "i");
				term = term.replace("v", "u");
				final_terms[i] = term;
			}
			
			for (int i = 0; i < (final_terms.length); i++) {
//				String term = final_terms[i];
				if(final_terms[i].length() != 0){
					Text final_val = new Text("<" + final_terms[i]+","+ val +">");
					if(hash.containsKey(final_terms[i])){
						ArrayList<String> ll = hash.get(final_terms[i]);
						for(int j =0; j<ll.size(); j++){
								Text word = new Text(ll.get(j));
								context.write(word, final_val);
							}
						}
					else{
						Text word = new Text(final_terms[i]);
						context.write(word, final_val);
					}
				}
			}
		}
	 }

	private static class MyReducer extends
	Reducer<Text, Text, Text, Text> {

		@Override
		public void reduce(Text key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			String val = "";
			for (Text value : values) {
				val = val + value.toString()+ " ";
			}
			Text final_val = new Text(val);
			context.write(key, final_val);
		}
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub
		String csvFile = "new_lemmatizer.csv";
		String line = "";
        hash = new HashMap<String, ArrayList<String>>();
       
		try {
            BufferedReader br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] csv_content = line.split(",");
                if(csv_content.length>1){
                	ArrayList<String> content = new ArrayList<String>();
                	for(int i = 1; i<csv_content.length; i++){
                		content.add(csv_content[i].toLowerCase());
                	}
                	hash.put(csv_content[0].toLowerCase(), content);
//                	content.clear();
                }
                
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
		// TODO Auto-generated method stub
        }
		
		Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Word_Count_Latin");
	    job.setJarByClass(Latin_count.class);
	    job.setMapperClass(MyMapper.class);
//	    job.setCombinerClass(MyReducer.class);
	    job.setReducerClass(MyReducer.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);

	}

}
