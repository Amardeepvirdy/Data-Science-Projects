import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Latin_pairs {
    public static HashMap<String, ArrayList<String>> hash;
	private static class MyMapper extends Mapper<LongWritable, Text, WPair, Text> {

		private final WPair pair = new WPair();
		@Override
		public void map(LongWritable key, Text line, Context context) throws IOException,
				InterruptedException {
			String text = line.toString();
			String[] parts = text.split(">");
			if(parts.length<2){
				return;
			}
			String val = parts[0] + ">";
			Text value = new Text(val);
			parts[1] = parts[1].replaceAll("[^a-zA-Z ]", "");
			String[] terms = parts[1].split(" ");
			String[] final_terms = new String[terms.length];
			for (int i = 0; i < terms.length; i++){
				String term = terms[i].toLowerCase();
				term = term.replace("j", "i");
				term = term.replace("v", "u");
				final_terms[i] = term;
			}
			

			for (int i = 0; i < (final_terms.length-1); i++) {
				String term = final_terms[i];
				if(term.length() != 0){
					for (int j = i + 1; j < final_terms.length; j++) {
						if (final_terms[j].length() != 0){
							String word2 = final_terms[j];
							if(term.compareTo(word2) < 0){
								pair.set(term, word2);
							}
							else{
								pair.set(word2, term);
							}
						}
						context.write(pair, value);
					}
				}
			}
		}
	}

	private static class MyReducer extends
			Reducer<WPair, Text, WPair, Text> {

		@Override
		public void reduce(WPair key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			String val = "";
			for (Text value : values) {
	             val = val + value.toString()+ " ";
	        }
			Text final_val = new Text(val);
			Text curr = key.get_current();
			Text part = key.get_partner();
			String current = curr.toString();
			String partner = part.toString();
			ArrayList<String> list1 = new ArrayList<String>();
			ArrayList<String> list2 = new ArrayList<String>();
			
			if(hash.containsKey(current)){
				list1 = hash.get(current);
			}
			else{
				list1.add(current);
			}
			
			if(hash.containsKey(partner)){
				list2 = hash.get(partner);
			}
			else{
				list2.add(partner);
			}

			for(int i = 0; i<list1.size(); i++){
				for(int j = 0; j<list2.size(); j++){
					WPair pair = new WPair();
					pair.set(list1.get(i),list2.get(j));
					context.write(pair, final_val);
				}
			}
		}
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		String csvFile = "new_lemmatizer.csv";
		String line = "";
        hash = new HashMap<String, ArrayList<String>>();
       
		try {
            BufferedReader br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] csv_content = line.split(",");
                if(csv_content.length>1){
                	ArrayList<String> content = new ArrayList<String>();
                	for(int i = 1; i<csv_content.length; i++){
                		content.add(csv_content[i].toLowerCase());
                	}
                	hash.put(csv_content[0].toLowerCase(), content);
//                	content.clear();
                }
                
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
		// TODO Auto-generated method stub
        }
		
		
		Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Word_Cooccurence_Latin_Pairs");
	    job.setJarByClass(Latin_pairs.class);
	    job.setMapperClass(MyMapper.class);
//	    job.setCombinerClass(MyReducer.class);
	    job.setReducerClass(MyReducer.class);
	    job.setOutputKeyClass(WPair.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}