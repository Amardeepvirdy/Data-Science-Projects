
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Latin_triplets {
    public static HashMap<String, ArrayList<String>> hash;
	private static class MyMapper extends Mapper<LongWritable, Text, WTriplets, Text> {

		private final WTriplets triplets = new WTriplets();
		@Override
		public void map(LongWritable key, Text line, Context context) throws IOException,
				InterruptedException {
			String text = line.toString();
			String[] parts = text.split(">");
			if(parts.length<2){
				return;
			}
			String val = parts[0] + ">";
			Text value = new Text(val);
			parts[1] = parts[1].replaceAll("[^a-zA-Z ]", "");
			String[] terms = parts[1].split(" ");
			String[] final_terms = new String[terms.length];
			for (int i = 0; i < terms.length; i++){
				String term = terms[i].toLowerCase();
				term = term.replace("j", "i");
				term = term.replace("v", "u");
				final_terms[i] = term;
			}
			

			for (int i = 0; i < (final_terms.length-2); i++) {
				if(final_terms[i].length() != 0){
					for (int j = i + 1; j < final_terms.length-1; j++) {
						if (final_terms[j].length() != 0){
							for(int k = j+1; k<final_terms.length; k++){
								if (final_terms[k].length() != 0){
									String[] temp = new String[3];
									temp[0] = final_terms[i];
									temp[1] = final_terms[j];
									temp[2] = final_terms[k];
									Arrays.sort(temp);
									triplets.set(temp[0], temp[1], temp[2]);
									context.write(triplets, value);
								}
							}
						}
					}
				}
			}
		}
	}

	private static class MyReducer extends
			Reducer<WTriplets, Text, WTriplets, Text> {

		@Override
		public void reduce(WTriplets key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			String val = "";
			for (Text value : values) {
	             val = val + value.toString()+ " ";
	        }
			Text final_val = new Text(val);
			Text curr = key.get_current();
			Text sec = key.get_second();
			Text thd = key.get_third();
			String current = curr.toString();
			String second = sec.toString();
			String third = thd.toString();
			ArrayList<String> list1 = new ArrayList<String>();
			ArrayList<String> list2 = new ArrayList<String>();
			ArrayList<String> list3 = new ArrayList<String>();
			
			if(hash.containsKey(current)){
				list1 = hash.get(current);
			}
			else{
				list1.add(current);
			}
			
			if(hash.containsKey(second)){
				list2 = hash.get(second);
			}
			else{
				list2.add(second);
			}
			
			if(hash.containsKey(third)){
				list3 = hash.get(third);
			}
			else{
				list3.add(third);
			}
			

			for(int i = 0; i<list1.size(); i++){
				for(int j = 0; j<list2.size(); j++){
					for(int k = 0; k<list3.size(); k++){
						WTriplets trip = new WTriplets();
						trip.set(list1.get(i),list2.get(j), list3.get(k));
						context.write(trip, final_val);
					}
				}
			}
		}
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		String csvFile = "new_lemmatizer.csv";
		String line = "";
        hash = new HashMap<String, ArrayList<String>>();
       
		try {
            BufferedReader br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] csv_content = line.split(",");
                if(csv_content.length>1){
                	ArrayList<String> content = new ArrayList<String>();
                	for(int i = 1; i<csv_content.length; i++){
                		content.add(csv_content[i].toLowerCase());
                	}
                	hash.put(csv_content[0].toLowerCase(), content);
//                	content.clear();
                }
                
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
		// TODO Auto-generated method stub
        }
		
		
		Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Word_Cooccurence_Latin_Pairs");
	    job.setJarByClass(Latin_triplets.class);
	    job.setMapperClass(MyMapper.class);
//	    job.setCombinerClass(MyReducer.class);
	    job.setReducerClass(MyReducer.class);
	    job.setOutputKeyClass(WTriplets.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
