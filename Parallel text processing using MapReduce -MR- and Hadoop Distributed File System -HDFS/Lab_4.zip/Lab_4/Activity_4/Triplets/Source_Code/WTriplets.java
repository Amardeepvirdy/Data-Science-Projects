import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class WTriplets implements Writable,WritableComparable <WTriplets> {
	
	private Text current;
    private Text second;
    private Text third;

	public WTriplets() {
		
		current = new Text();
		second = new Text();
		third = new Text();
		// TODO Auto-generated constructor stub
	}

	public int compareTo(WTriplets triplets) {
		int c = current.compareTo(triplets.current);
		if( c == 0 ){
			c = second.compareTo(triplets.second);
			if(c == 0){
				c = third.compareTo(triplets.third);
			}
		}
		// TODO Auto-generated method stub
		return c;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		current.readFields(arg0);
		second.readFields(arg0);
		third.readFields(arg0);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		current.write(arg0);
		second.write(arg0);
		third.write(arg0);
		// TODO Auto-generated method stub
		
	}
	
	public void set(String current, String second, String third){
        this.current.set(current);
        this.second.set(second);
        this.third.set(third);
    }
	
	public Text get_current(){
        return current;
    }
	
	public Text get_second(){
        return second;
    }
	
	public Text get_third(){
		return third;
	}
	
	@Override
    public String toString() {
        return current.toString() +", "+ second.toString() + ", " + third.toString();
    }


}

